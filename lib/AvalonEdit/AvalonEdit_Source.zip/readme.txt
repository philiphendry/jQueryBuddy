This is AvalonEdit 4.0.0.5950, the CodeProject release of AvalonEdit corresponding to SharpDevelop 4.0 Beta 1.

Code Project article: http://www.codeproject.com/KB/edit/AvalonEdit.aspx
AvalonEdit website:   http://www.avalonedit.net/
SharpDevelop website: http://www.icsharpcode.net/OpenSource/SD/

Copyright Daniel Grunwald, 2008-2010
ICSharpCode.AvalonEdit is licensed under the GNU LGPL. See license.txt for details.
The AvalonEdit.Sample application is licensed under the MIT/X11 license. See the file headers of AvalonEdit.Sample\*.cs for details.
